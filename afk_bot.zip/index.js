// AFK Bot with random movement/look and robust error handling
const mineflayer = require('mineflayer')

const CONFIG = {
  host: 'Pheinmanski.aternos.me',
  port: 25854,
  username: 'AFK_BOT',
  version: false,
  auth: 'offline',
  initialDelayMs: 5000,
  moveIntervalMin: 2000,
  moveIntervalMax: 5000,
  lookIntervalMin: 1500,
  lookIntervalMax: 3500,
  chatInterval: 300000
}

function rand(min, max) {
  return Math.floor(Math.random() * (max - min)) + min
}

function createBot() {
  console.log('[BOT] Starting bot...')
  let bot = mineflayer.createBot({
    host: CONFIG.host,
    port: CONFIG.port,
    username: CONFIG.username,
    version: CONFIG.version,
    auth: CONFIG.auth
  })

  // Chat loop
  function chatLoop() {
    try {
      bot.chat('/w AFK_BOT hi')
    } catch(err) {}
    setTimeout(chatLoop, CONFIG.chatInterval)
  }

  // Random movement + jumping
  function movementLoop() {
    try {
      const dirs = ['forward', 'back', 'left', 'right']
      dirs.forEach(d => bot.setControlState(d, false))
      const pick = dirs[Math.floor(Math.random()*dirs.length)]
      bot.setControlState(pick, true)

      if (Math.random() < 0.3) {
        bot.setControlState('jump', true)
        setTimeout(() => bot.setControlState('jump', false), 300)
      }
    } catch(err) {}
    setTimeout(movementLoop, rand(CONFIG.moveIntervalMin, CONFIG.moveIntervalMax))
  }

  // Random looking
  function lookLoop() {
    try {
      const yaw = Math.random() * Math.PI * 2
      const pitch = (Math.random() * 1.5) - 0.75
      bot.look(yaw, pitch, true)
    } catch(err) {}
    setTimeout(lookLoop, rand(CONFIG.lookIntervalMin, CONFIG.lookIntervalMax))
  }

  bot.once('spawn', () => {
    console.log('[BOT] Spawned.')
    setTimeout(() => {
      chatLoop()
      movementLoop()
      lookLoop()
    }, CONFIG.initialDelayMs)
  })

  function reconnect() {
    console.log('[BOT] Reconnecting in 5s...')
    setTimeout(createBot, 5000)
  }

  bot.on('kicked', (r) => {
    console.log('[KICKED]', r)
    reconnect()
  })

  bot.on('error', (e) => {
    console.log('[ERROR]', e)
    reconnect()
  })

  bot.on('end', reconnect)
}

createBot()
